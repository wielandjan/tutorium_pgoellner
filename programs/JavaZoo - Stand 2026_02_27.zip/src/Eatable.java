public interface Eatable {
}
